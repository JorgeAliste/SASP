/*
 var mysql = require('mysql');
 var connection = mysql.createConnection({
 host : 'localhost',
 user : 'root',
 password : '',
 database : 'fisfinder120'
 });
 */

var mysql = require('mysql');
var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: ''
});

var express = require('express');

//instanciar
var app = express();

//ruteo

app.use(express.static(__dirname + '/Views'));
app.get('/', function (req, res) {
    res.sendfile(__dirname + '/Views/index.html');
});
app.get('/about', function (req, res) {
    res.sendfile(__dirname + 'Views/about.html');
});
app.use(express.static('response.write("Hola Mundo");public'));

var http = require('http');
var url = require('url');
var fs = require('fs');
var querystring = require('querystring');

var mime = {
    'html': 'text/html',
    'css': 'text/css',
    'jpg': 'image/jpg',
    'ico': 'image/x-icon',
    'mp3': 'audio/mpeg3',
    'mp4': 'video/mp4'
};

var servidor = http.createServer(function (pedido, respuesta) {
    var objetourl = url.parse(pedido.url);
    var camino = 'app' + objetourl.pathname;
    if (camino == 'app/')
        camino = 'app/index.html';
    encaminar(pedido, respuesta, camino);
});

servidor.listen(9000);

function encaminar(pedido, respuesta, camino) {
    console.log(camino);
    switch (camino) {
        case 'app/views/registro2': {
            registro2(pedido, respuesta);
            break;
        }
        case 'app/views/power': {
            power(pedido, respuesta);
            break;
        }


        default : {
            fs.exists(camino, function (existe) {
                if (existe) {
                    fs.readFile(camino, function (error, contenido) {
                        if (error) {
                            respuesta.writeHead(500, {'Content-Type': 'text/plain'});
                            respuesta.write('Error interno');
                            respuesta.end();
                        } else {
                            var vec = camino.split('.');
                            var extension = vec[vec.length - 1];
                            var mimearchivo = mime[extension];
                            respuesta.writeHead(200, {'Content-Type': mimearchivo});
                            respuesta.write(contenido);
                            respuesta.end();
                        }
                    });
                } else {
                    respuesta.writeHead(404, {'Content-Type': 'text/html'});
                    respuesta.write('<!doctype html><html><head></head><body>Recurso inexistente</body></html>');
                    respuesta.end();
                }
            });
        }
    }
}

console.log('Servidor web iniciado');

function registro2(pedido, respuesta) {
    var dato = '';
    var info = '';
    pedido.on('data', function (datosparciales) {
        info += datosparciales;
    });
    pedido.on('end', function () {
        var formulario = querystring.parse(info);
        respuesta.writeHead(200, {'Content-Type': 'text/html'});

        connection.query("SELECT * FROM estudiante WHERE Email = ?", formulario['email'], function (err, rows) {
            if (err) throw err;

            if (rows.length != 0) {
                respuesta.end("NO");
            }
            else {

                var datos = {
                    nombre: formulario['nombre'],
                    rut: formulario['rut'],
                    email: formulario['email'],
                    password: formulario['clave'],
                    rol: formulario['rol'],
                    tipo: 4
                };
                connection.query("INSERT INTO estudiante SET ?", datos, function (err, rows) {
                    if (err) throw err;
                    respuesta.end(formulario['email']);
                });
            }

        });
    });
}

(function () {
    'use strict';

    const fs = require('fs');
    const elasticsearch = require('elasticsearch');
    const esClient = new elasticsearch.Client({
        host: '127.0.0.1:9200',
        log: 'error'
    });

    const bulkIndex = function bulkIndex(index, type, data) {
        let bulkBody = [];

        data.forEach(item => {
            bulkBody.push({
            index: {
                _index: index,
                _type: type,
                _id: item.id
            }
        });

        bulkBody.push(item);
    });

        esClient.bulk({body: bulkBody})
            .then(response => {
            let errorCount = 0;
        response.items.forEach(item => {
            if (item.index && item.index.error) {
            console.log(++errorCount, item.index.error);
        }
    });
        console.log(`Successfully indexed ${data.length - errorCount} out of ${data.length} items`);
    })
        .catch(console.err);
    };

    // only for testing purposes
    // all calls should be initiated through the module
    const test = function test() {
        const articlesRaw = fs.readFileSync('data.json');
        const articles = JSON.parse(articlesRaw);
        console.log(`${articles.length} items parsed from data file`);
        bulkIndex('library', 'article', articles);
    };

    test();

    module.exports = {
        bulkIndex
    };
} ());


function power(pedido, respuesta) {

    'use strict';
    const readline = require('readline');
    const elasticsearch = require('elasticsearch');
    const esClient = new elasticsearch.Client({
        host: '127.0.0.1:9200',
        log: 'error'
    });
    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    const search = function search(index, body, arreglo) {
        return esClient.search({index: index, body: body});
    };

    const test = function test(texto, cantidad) {
        let body = {
            size: cantidad,
            from: 0,
            query: {
                match: {
                    title: {
                        query: texto,
                        //minimum_should_match: 3,
                        fuzziness: 2
                    }
                }
            }
        };
        var resultados = [];
        var palabras = "";

        palabras += "-------------------------------------------------------------------------------------------------";
        palabras += "Resultados de la Búsqueda";
        palabras +=  "------------------------------------------------------------------------------------------------------------------";
            "\n\n";
        respuesta.writeHead(200, {'Content-Type': 'text/html'});
        console.log(`Mostrando documentos relacionados con '${body.query.match.title.query}' (se muestran ${body.size} resultados)...\t`);
        search('library', body, resultados)
            .then(results => {
            //console.log(`found ${results.hits.total} items in ${results.took}ms`);
            if (results.hits.total > 0) console.log(`Documentos encontrados:`);
        results.hits.hits.forEach((hit, index) =>
        {
            resultados.push(`${hit._source.title}`);
            palabras += "Título:";
            palabras += (`${hit._source.title}`);
            palabras +=  "->";
            resultados.push(`${hit._source.link}`);
            palabras += "Enlace:";
            palabras += (`${hit._source.link}`);
            palabras +=  "---------------------";

        //console.log(`\t${body.from + ++index} - ${hit._source.title} ${hit._source.link} (score: ${hit._score})`);
    });
        respuesta.end(palabras);
        mostrarLista(resultados);


    })
        .catch(console.error);
        return(resultados)
    };
    var arre = [];

    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    var busqueda = "";
    var info = "";

    pedido.on('data', function (datosparciales) {
        info += datosparciales;
        console.log(info);
    });
    pedido.on('end', function () {
        var formulario = querystring.parse(info);
        console.log(formulario['busqueda']);
        busqueda = formulario['busqueda'];
        test(busqueda, 10);
    });




    /*rl.question('Ingrese la busqueda a realizar: ', (answer1) => {
        rl.question('Defina el número de resultados: ', (answer2) => {
        test(answer1, 10)
        rl.close();
});
});
     */

    module.exports = {
        search
    };
};

function mostrarLista(arreglo)
{
    for (i = 0; i < arreglo.length; i++) {
        if(i%2 == 0)
        {
            console.log("Título: " + arreglo[i]);
        }
        else
        {
            console.log("Enlace:" + arreglo[i] + '\t');
            console.log("----------------------------------------------");
        }
    }
}


