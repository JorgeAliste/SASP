// Creación del módulo
var angularRoutingApp = angular.module('angularRoutingApp', ['ngRoute','controller']);

// Configuración de las rutas
angularRoutingApp.config(function($routeProvider) {

  $routeProvider
      .when('/', {
        templateUrl : '../views/index.html',
        controller  : 'HomeCtrl'
      })
      .when('/adaptador', {
        templateUrl : '../views/results.html',
        controller  : 'resultsCtrl'
      })
      .when('/asimilador', {
          templateUrl : '../views/results.html',
          controller  : 'resultsCtrl'
      })
      .when('/convergente', {
          templateUrl : '../views/results.html',
          controller  : 'resultsCtrl'
      })
      .when('/divergente', {
          templateUrl : '../views/results.html',
          controller  : 'resultsCtrl'
      })
      .when('/resultadosBusqueda', {
          templateUrl : '../views/resultadosBusqueda.html',
          controller  : 'resultadosBusquedaCtrl'
      })
      .otherwise({
        redirectTo: '/'
      });
});

angularRoutingApp.controller('mainController', function($scope) {
  $scope.message = 'Hola, Mundo!';
});

angularRoutingApp.controller('aboutController', function($scope) {
  $scope.message = 'Esta es la página "Acerca de"';
});

angularRoutingApp.controller('contactController', function($scope) {
  $scope.message = 'Esta es la página de "Contacto", aquí podemos poner un formulario';
});




